-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2018 at 09:06 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `logininfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `student_id` varchar(30) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `year` varchar(10) NOT NULL,
  `course` varchar(30) NOT NULL,
  `sub_semi1` longtext NOT NULL,
  `sub_semi2` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`student_id`, `faculty`, `year`, `course`, `sub_semi1`, `sub_semi2`) VALUES
('trt77', 'School of Computing', 'First year', 'BSc in Information Systems', '[C1205, C1209]', 'javax.swing.DefaultListSelectionModel 1943368695 ={}'),
('423', 'School of Business', 'First year', 'BSc in Management', '[B1201, B1202, B1203, B1204, B1207, B1206, B1209, B1205]', 'javax.swing.DefaultListSelectionModel 960291626 ={}'),
('45', 'School of Computing', 'First year', 'BSc in Information Systems', '[C1201, C1202, C1203, C1204, C1207, C1209, C1210, C1206]', 'javax.swing.DefaultListSelectionModel 641558007 ={0, 1, 2, 3, 4, 5}'),
('fddr', 'School of Computing', 'First year', 'BSc in Computer Science', '[B1301, B1302, B1303, B1304, B1308, B1307, B1309, B1306]', 'javax.swing.DefaultListSelectionModel 586387275 ={0, 1, 2, 3, 4, 5, 6}'),
('', 'School of Engineering', 'First year', 'BSc in Mechanical Engineering', '[E1201, E1202, E1203, E1204, E1208, E1207, E1209, E1206]', '[E1211 - Introductory Mechanics I, E1212 - Engineering Materials I, E1213 - Intelligent Systems , E1214 - Communication Systems I, E1217, E1219]'),
('34', 'School of Business', 'First year', 'BSc in Management', '[B1201, B1202, B1203, B1204, B1208, B1206, null, B1209, B1207]', '[B1211, B1212, B1213, B1214, B1217, B1218, B1216]');

-- --------------------------------------------------------

--
-- Table structure for table `instructordetails`
--

CREATE TABLE `instructordetails` (
  `full_name` varchar(30) NOT NULL,
  `instructor_id` varchar(15) NOT NULL,
  `e_mail` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact_no` int(10) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(20) NOT NULL,
  `faculty` varchar(40) NOT NULL,
  `for_year` varchar(20) NOT NULL,
  `course` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `subject_code` varchar(30) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `institute` varchar(30) NOT NULL,
  `year` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instructordetails`
--

INSERT INTO `instructordetails` (`full_name`, `instructor_id`, `e_mail`, `address`, `contact_no`, `birth_date`, `gender`, `faculty`, `for_year`, `course`, `subject`, `subject_code`, `qualification`, `institute`, `year`) VALUES
('fgdf', 'fdgdf', 'fdgdf', 'fgdf', 5646, '2018-06-05', 'Female', 'School of Computing', '1st Year', 'MSc in Computer Networks', 'tyr', 'trr', 'rru', 'tryr', 677);

-- --------------------------------------------------------

--
-- Table structure for table `lecturerdetails`
--

CREATE TABLE `lecturerdetails` (
  `full_name` varchar(30) NOT NULL,
  `lecturer_id` varchar(15) NOT NULL,
  `e_mail` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact_no` int(10) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(20) NOT NULL,
  `faculty` varchar(40) NOT NULL,
  `for_year` varchar(20) NOT NULL,
  `course` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `subject_code` varchar(30) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `institute` varchar(30) NOT NULL,
  `year` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturerdetails`
--

INSERT INTO `lecturerdetails` (`full_name`, `lecturer_id`, `e_mail`, `address`, `contact_no`, `birth_date`, `gender`, `faculty`, `for_year`, `course`, `subject`, `subject_code`, `qualification`, `institute`, `year`) VALUES
('fr', 'fer', 'er', 'er', 5346, '2018-06-05', 'Male', 'School of Business', '1st Year', 'MSc in Marketing', 'erg', 'gdfg', 'dgddfg', 'rger', 35435);

-- --------------------------------------------------------

--
-- Table structure for table `pgstdfees`
--

CREATE TABLE `pgstdfees` (
  `student_id` varchar(30) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `fees` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pgstdfees`
--

INSERT INTO `pgstdfees` (`student_id`, `faculty`, `course`, `fees`) VALUES
('', 'School of Business', 'BSc in Business Management', '2000'),
('fddr', 'School of Computing', 'BSc in Computer Science', '1001');

-- --------------------------------------------------------

--
-- Table structure for table `pgstucourse`
--

CREATE TABLE `pgstucourse` (
  `student_id` varchar(30) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `academic_year` varchar(30) NOT NULL,
  `course` varchar(50) NOT NULL,
  `sub_semi1` longtext NOT NULL,
  `sub_semi2` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pgstucourse`
--

INSERT INTO `pgstucourse` (`student_id`, `faculty`, `academic_year`, `course`, `sub_semi1`, `sub_semi2`) VALUES
('dfh', 'School of Computing', 'First year', 'MSc in Computer Networks', '[PGB1101, PGB1102, PGB1103, PGB1104]', '[PGB1111, PGB1112, PGB1113, PGB1114]'),
('asdfaseg', 'School of Computing', 'First year', 'MSc in Computer Networks', '[PGB1101, PGB1102, PGB1103, PGB1104]', '[PGB1111, PGB1112, PGB1113, PGB1114]'),
('as', 'School of Business', 'Second Year', 'MSc in Marketing', '[PGB2101, PGB2102, PGB2103, PGB2104]', '[PGB2111, PGB2112, PGB2113, PGB2114]');

-- --------------------------------------------------------

--
-- Table structure for table `postgraduatestudent`
--

CREATE TABLE `postgraduatestudent` (
  `full_name` varchar(30) NOT NULL,
  `student_id` varchar(15) NOT NULL,
  `birth_date` varchar(20) NOT NULL,
  `e_mail` varchar(30) NOT NULL,
  `index_no` int(10) NOT NULL,
  `intake` varchar(10) NOT NULL,
  `year` int(10) NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `al_stream` varchar(20) NOT NULL,
  `z_score` varchar(10) NOT NULL,
  `island_rank` int(10) NOT NULL,
  `faculty` varchar(30) NOT NULL,
  `course` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `institution` text NOT NULL,
  `passed_year` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postgraduatestudent`
--

INSERT INTO `postgraduatestudent` (`full_name`, `student_id`, `birth_date`, `e_mail`, `index_no`, `intake`, `year`, `contact_no`, `gender`, `al_stream`, `z_score`, `island_rank`, `faculty`, `course`, `address`, `qualification`, `institution`, `passed_year`) VALUES
('Raja', 'wqeqw', '2018-07-18', 'qweqe@gmail.com', 343535, 'July', 4324, '332434235', 'Female', 'Bio Stream', '44', 3453, 'School of Business', 'MSc in Marketing', 'qweq', 'eeff', 't56456fsg', 4353);

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `student_id` varchar(30) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `course` varchar(30) NOT NULL,
  `semester` int(10) NOT NULL,
  `tot_credits` int(10) NOT NULL,
  `gpa` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sobtimeslot`
--

CREATE TABLE `sobtimeslot` (
  `type` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `lecturer_instructor` varchar(50) NOT NULL,
  `Day` varchar(50) NOT NULL,
  `time_from` varchar(50) NOT NULL,
  `time_to` varchar(50) NOT NULL,
  `lecturer_room_lab` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sobtimeslot`
--

INSERT INTO `sobtimeslot` (`type`, `year`, `semester`, `subject`, `lecturer_instructor`, `Day`, `time_from`, `time_to`, `lecturer_room_lab`) VALUES
('Undergraduate', '1st year', '1st Semester', 'A1', 'a', 'Monday', '8.00', '9.00', 'LAB A'),
('Undergraduate', '2nd year', '2nd Semester', 'A2', 'a', 'Tuesday', '10.00', '12.00', 'LAB B'),
('Undergraduate', '1st year', '2nd Semester', 'A3', '', 'Wednesday', '3.00', '4.00', 'LAB D'),
('Undergraduate', '1st year', '2nd Semester', 'A4', 'ssd', 'Tuesday', '10.00', '2.00', 'LAB C'),
('Postgraduate', '3rd year', '2nd Semester', 'A5', 'ssd', 'Wednesday', '10.00', '2.00', 'LAB C'),
('Postgraduate', '4th year', '2nd Semester', 'A56', 'ssd', 'Wednesday', '10.00', '2.00', 'LECR C'),
('Postgraduate', '2nd year', '2nd Semester', 'A6', 'ssd', 'Wednesday', '12.00', '3.00', 'LAB E'),
('Postgraduate', '2nd year', '2nd Semester', 'A67', 'ssd', 'Thursday', '2.00', '3.00', 'LAB E'),
('Postgraduate', '2nd year', '2nd Semester', 'A67', 'ssd', 'Monday', '12.00', '3.00', 'LAB E'),
('Postgraduate', '2nd year', '2nd Semester', 'A67', 'ssd', 'Monday', '12.00', '3.00', 'LAB E'),
('Postgraduate', '2nd year', '1st Semester', 'A67', 'ssd', 'Monday', '12.00', '3.00', 'LAB E'),
('Postgraduate', '2nd year', '1st Semester', 'A67', 'ssd', 'Wednesday', '12.00', '3.00', 'LAB E'),
('Postgraduate', '2nd year', '1st Semester', 'A698', 'ssd', 'Friday', '12.00', '3.00', 'LAB E');

-- --------------------------------------------------------

--
-- Table structure for table `subjectdetails`
--

CREATE TABLE `subjectdetails` (
  `faculty` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `sub_name` varchar(50) NOT NULL,
  `sub_id` varchar(5) NOT NULL,
  `type` varchar(20) NOT NULL,
  `academic_year` varchar(4) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `sub_credits` int(5) NOT NULL,
  `fees` varchar(10) NOT NULL,
  `lecturer` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjectdetails`
--

INSERT INTO `subjectdetails` (`faculty`, `course`, `sub_name`, `sub_id`, `type`, `academic_year`, `semester`, `sub_credits`, `fees`, `lecturer`) VALUES
('School of Business', 'BSc in Business Management', 'Business Process', 'B1101', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'jg'),
('School of Business', 'BSc in Business Management', ' Management Process', 'B1102', 'Undergraduate', '1', 'Semester 1', 4, '10001', 'gg'),
('School of Business', 'BSc in Business Management', 'Business Communication', 'B1103', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'fvfd'),
('School of Business', 'BSc in Business Management', 'Financial Accounting', 'B1104', 'Undergraduate', '1', 'Semester 1', 2, '3200', 'dfs'),
('School of Business', 'BSc in Business Management', 'Economics for Managers', 'B1105', 'Undergraduate', '1', 'Semester 1', 2, '2700', 'guguu'),
('School of Business', 'BSc in Business Management', 'Managerial Accounting', 'B1106', 'Undergraduate', '1', 'Semester 1', 3, '2500', 'gug'),
('School of Business', 'BSc in Business Management', 'Business Environment', 'B1107', 'Undergraduate', '1', 'Semester 1', 3, '3500', 'fff'),
('School of Business', 'BSc in Business Management', 'Business Statistics', 'B1108', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'gg'),
('School of Business', 'BSc in Business Management', 'ICT', 'B1109', 'Undergraduate', '1', 'Semester 1', 3, '3500', 'gyn'),
('School of Business', 'BSc in Business Management', 'Organizational Behavior', 'B2101', 'Undergraduate', '2', 'Semester 1', 2, '3000', 'gyn'),
('School of Business', 'BSc in Business Management', 'Accounting', 'B2102', 'Undergraduate', '2', 'Semester 1', 3, '2900', 'rgg'),
('School of Business', 'BSc in Business Management', 'Marketing Management', 'B2103', 'Undergraduate', '2', 'Semester 1', 3, '3000', 'rgg'),
('School of Business', 'BSc in Business Management', 'Financial Statics', 'B2104', 'Undergraduate', '2', 'Semester 1', 2, '3000', 'rggd'),
('School of Business', 'BSc in Business Management', 'Industrial Realations', 'B2105', 'Undergraduate', '2', 'Semester 1', 3, '4000', 'rggd'),
('School of Business', 'BSc in Business Management', 'Quality Management', 'B2106', 'Undergraduate', '2', 'Semester 1', 2, '2800', 'rdsf'),
('School of Business', 'BSc in Business Management', 'HR Management', 'B2107', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'sdfd'),
('School of Business', 'BSc in Business Management', 'Logistics Management', 'B2108', 'Undergraduate', '2', 'Semester 1', 2, '3500', 'sgh'),
('School of Business', 'BSc in Business Management', 'Financial Management', 'B2109', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'esdfs'),
('School of Business', 'BSc in Business Management', 'Marketing Management', 'B2110', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'dsd'),
('School of Business', 'BSc in Business Management', 'Industrial Training', 'B3101', 'Undergraduate', '3', 'Semester 1', 3, '3000', 'sd'),
('School of Business', 'BSc in Business Management', 'HR Development', 'B3102', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'sdas'),
('School of Business', 'BSc in Business Management', 'Marketing Process', 'B3103', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'sdf'),
('School of Business', 'BSc in Business Management', 'HR Practice', 'B3104', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'ewer'),
('School of Business', 'BSc in Business Management', 'Strategic Management', 'B3105', 'Undergraduate', '3', 'Semester 1', 3, '3200', 'ewer'),
('School of Business', 'BSc in Business Management', 'Management Information Systems', 'B3106', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'asd'),
('School of Business', 'BSc in Business Management', 'Business & Industrial Law', 'B3107', 'Undergraduate', '3', 'Semester 1', 3, '3500', 'das'),
('School of Business', 'BSc in Business Management', 'Employee Resourcing', 'B3108', 'Undergraduate', '3', 'Semester 1', 3, '2500', 'sad'),
('School of Business', 'BSc in Business Management', 'International Business Management', 'B3109', 'Undergraduate', '3', 'Semester 1', 2, '3500', 'swqs'),
('School of Business', 'BSc in Business Management', 'Advanced Financial Accounting', 'B3110', 'Undergraduate', '3', 'Semester 1', 3, '2500', 'swsd'),
('School of Business', 'BSc in Business Management', 'Internal Management', 'B4101', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'zxzszx'),
('School of Business', 'BSc in Business Management', 'Research Methodology', 'B4102', 'Undergraduate', '4', 'Semester 1', 4, '3500', 'zxzszx'),
('School of Business', 'BSc in Business Management', 'Employee Management', 'B4103', 'Undergraduate', '4', 'Semester 1', 3, '2500', 'zxzszx'),
('School of Business', 'BSc in Business Management', 'IT Management', 'B4104', 'Undergraduate', '4', 'Semester 1', 3, '2500', 'ds'),
('School of Business', 'BSc in Business Management', 'Rewards Management', 'B4105', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'dsas'),
('School of Business', 'BSc in Business Management', 'Performance Management', 'B4106', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'zsa'),
('School of Business', 'BSc in Business Management', 'Strategic HR Management', 'B4107', 'Undergraduate', '4', 'Semester 1', 3, '2700', 'ass'),
('School of Business', 'BSc in Business Management', 'HR Processes & Systems', 'B4108', 'Undergraduate', '4', 'Semester 1', 4, '3500', 'ass'),
('School of Business', 'BSc in Business Management', 'HR Training', 'B4109', 'Undergraduate', '4', 'Semester 1', 4, '4000', 'sds'),
('School of Business', 'BSc in Business Management', 'IT Environment', 'B4110', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'assa'),
('School of Business', 'BSc in Management', 'Managerial Accounting', 'B1205', 'Undergraduate', '1', 'Semester 1', 3, '3200', 'efzx'),
('School of Business', 'BSc in Management', 'Business Environment', 'B1203', 'Undergraduate', '1', 'Semester 1', 3, '4000', 'efzx'),
('School of Business', 'BSc in Management', 'Financial Account I', 'B1204', 'Undergraduate', '1', 'Semester 1', 4, '4000', 'efzx'),
('School of Business', 'BSc in Management', 'Business Communication', 'B1201', 'Undergraduate', '1', 'Semester 1', 3, '3200', 'efe'),
('School of Business', 'BSc in Management', 'Management Account', 'B1202', 'Undergraduate', '1', 'Semester 1', 2, '2800', 'efegh'),
('School of Business', 'BSc in Management', 'Business Mathematics', 'B1206', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'Critical Enabling', 'B1207', 'Undergraduate', '1', 'Semester 1', 3, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'Business Statics', 'B1208', 'Undergraduate', '1', 'Semester 1', 4, '3500', 'efzx'),
('School of Business', 'BSc in Management', 'Economics', 'B1209', 'Undergraduate', '1', 'Semester 1', 3, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'HR Training', 'B2201', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'Industrial Relations', 'B2202', 'Undergraduate', '2', 'Semester 1', 2, '3700', 'efzx'),
('School of Business', 'BSc in Management', 'Marketing Process', 'B2203', 'Undergraduate', '2', 'Semester 1', 3, '3200', 'efzx'),
('School of Business', 'BSc in Management', 'Marketing Management', 'B2204', 'Undergraduate', '2', 'Semester 1', 2, '2800', 'efzx'),
('School of Business', 'BSc in Management', 'Quality Management', 'B2205', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'efzx'),
('School of Business', 'BSc in Management', 'HR Management', 'B2206', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'efzx'),
('School of Business', 'BSc in Management', 'Logistics Management', 'B2207', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'Advanced Financial Accounting', 'B2208', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'Professional Development', 'B2209', 'Undergraduate', '2', 'Semester 1', 3, '2600', 'efzx'),
('School of Business', 'BSc in Management', 'Financial Management', 'B2210', 'Undergraduate', '2', 'Semester 1', 3, '2600', 'efzx'),
('School of Business', 'BSc in Management', 'Business & Industrial Law', 'B3201', 'Undergraduate', '3', 'Semester 1', 4, '3600', 'efzx'),
('School of Business', 'BSc in Management', 'Procurement Management', 'B3202', 'Undergraduate', '3', 'Semester 1', 3, '2600', 'efzx'),
('School of Business', 'BSc in Management', 'Inventory Management', 'B3203', 'Undergraduate', '3', 'Semester 1', 2, '2600', 'efzx'),
('School of Business', 'BSc in Management', 'Management Information', 'B3204', 'Undergraduate', '3', 'Semester 1', 3, '3600', 'efzx'),
('School of Business', 'BSc in Management', 'Employee Resourcing', 'B3205', 'Undergraduate', '3', 'Semester 1', 3, '2600', 'efzx'),
('School of Business', 'BSc in Management', 'Strategic Management', 'B3206', 'Undergraduate', '3', 'Semester 1', 2, '2600', 'efzx'),
('School of Business', 'BSc in Management', 'HR Development', 'B3207', 'Undergraduate', '3', 'Semester 1', 3, '2600', 'efzx'),
('School of Business', 'BSc in Management', 'International Business Management', 'B3208', 'Undergraduate', '3', 'Semester 1', 4, '3500', 'efzx'),
('School of Business', 'BSc in Management', 'HR Practice', 'B3209', 'Undergraduate', '3', 'Semester 1', 4, '4000', 'efzx'),
('School of Business', 'BSc in Management', 'Financial Account II', 'B3210', 'Undergraduate', '3', 'Semester 1', 2, '2800', 'efzx'),
('School of Business', 'BSc in Management', 'Supply Chain Management', 'B4201', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'efzx'),
('School of Business', 'BSc in Management', 'Maritime Law', 'B4202', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'efzx'),
('School of Business', 'BSc in Management', 'Logistics Managing', 'B4203', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'Researching', 'B4204', 'Undergraduate', '4', 'Semester 1', 4, '3500', 'efzx'),
('School of Business', 'BSc in Management', 'Transportation Logistics', 'B4205', 'Undergraduate', '4', 'Semester 1', 3, '2500', 'efzx'),
('School of Business', 'BSc in Management', 'Export Management', 'B4206', 'Undergraduate', '4', 'Semester 1', 3, '2700', 'efzx'),
('School of Business', 'BSc in Management', 'Import Management', 'B4207', 'Undergraduate', '4', 'Semester 1', 3, '2900', 'efzx'),
('School of Business', 'BSc in Management', 'IT Management', 'B4208', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'efzx'),
('School of Business', 'BSc in Management', 'Rewards Management', 'B4209', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'efzx'),
('School of Business', 'BSc in Management', 'HR Management II', 'B4210', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'efzx'),
('School of Business', 'BSc in Margeting Management', 'Introduction to Management', 'B1301', 'Undergraduate', '1', 'Semester 1', 3, '2900', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'World of Business', 'B1302', 'Undergraduate', '1', 'Semester 1', 2, '2900', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Marketing Communication', 'B1303', 'Undergraduate', '1', 'Semester 1', 3, '3400', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Global Communication', 'B1304', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'ICT for Communication', 'B1305', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Personal Development', 'B1306', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Communication Studies', 'B1307', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Professional purposes I', 'B1308', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Intercultural Communication', 'B1309', 'Undergraduate', '1', 'Semester 1', 3, '3500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Visual Communication', 'B2301', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Business Ethics', 'B2302', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'International Business', 'B2303', 'Undergraduate', '2', 'Semester 1', 2, '2800', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Research Method I', 'B2304', 'Undergraduate', '2', 'Semester 1', 3, '3000', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Advertising', 'B2305', 'Undergraduate', '2', 'Semester 1', 3, '2700', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Communication Research', 'B2306', 'Undergraduate', '2', 'Semester 1', 3, '3000', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Interpersonal Communication', 'B2307', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Corporate Communication', 'B2308', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Law for Communication', 'B2309', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Organizational Behavior', 'B2310', 'Undergraduate', '2', 'Semester 1', 2, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Micro Economics', 'B3301', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Skills Training', 'B3302', 'Undergraduate', '3', 'Semester 1', 3, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Financial Accounting', 'B3303', 'Undergraduate', '3', 'Semester 1', 3, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Business Communication', 'B3304', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Project Management', 'B3305', 'Undergraduate', '3', 'Semester 1', 3, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Global Communication II', 'B3306', 'Undergraduate', '3', 'Semester 1', 3, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Marketing Communication II', 'B3307', 'Undergraduate', '3', 'Semester 1', 3, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Corporate Finance', 'B3308', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Taxation', 'B3309', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Risk Management', 'B3310', 'Undergraduate', '3', 'Semester 1', 3, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Research Method II', 'B4301', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Research Report', 'B4302', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Business Valuation', 'B4303', 'Undergraduate', '4', 'Semester 1', 3, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Financial Statement', 'B4304', 'Undergraduate', '4', 'Semester 1', 3, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Auditing', 'B4305', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Professional Practice', 'B4306', 'Undergraduate', '4', 'Semester 1', 2, '3500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Advanced Accounting', 'B4307', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Strategic Management', 'B4308', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Portfolio Management', 'B4309', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'ggg'),
('School of Business', 'BSc in Margeting Management', 'Computer Based Accounting', 'B4310', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Data Structures I', 'C1101', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Programming I', 'C1102', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Database I', 'C1103', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Computer Systems I', 'C1104', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Mathematics', 'C1105', 'Undergraduate', '1', 'Semester 1', 2, '2900', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Laboratory', 'C1106', 'Undergraduate', '1', 'Semester 1', 2, '2900', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Computer Architecture', 'C1107', 'Undergraduate', '1', 'Semester 1', 2, '2900', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Development', 'C1108', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Data Communication', 'C1109', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Introduction to Computer Science', 'C1110', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Data Structures III', 'C2101', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Programming III', 'C2102', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Networking I', 'C2103', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Software Engineering I', 'C2104', 'Undergraduate', '2', 'Semester 1', 2, '2800', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Software Architecture', 'C2105', 'Undergraduate', '2', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Human Computer Interaction', 'C2106', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Complexity', 'C2107', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Computer Systems II', 'C2108', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Enterprise Application', 'C2109', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'System Analysis', 'C2110', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Computational Theory', 'C3101', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Programming V', 'C3102', 'Undergraduate', '3', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Networking II', 'C3103', 'Undergraduate', '3', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Industrial Visit', 'C3104', 'Undergraduate', '3', 'Semester 1', 3, '4000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Mobile Application', 'C3105', 'Undergraduate', '3', 'Semester 1', 2, '2700', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Wireless Technologies', 'C3106', 'Undergraduate', '3', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Advance Database', 'C3107', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Compile Design', 'C3108', 'Undergraduate', '3', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'SW Process Management', 'C3109', 'Undergraduate', '3', 'Semester 1', 3, '2900', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Cryptography', 'C3110', 'Undergraduate', '3', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Researching', 'C4101', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Internet of Things', 'C4102', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Dataware Housing', 'C4103', 'Undergraduate', '4', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Database II', 'C4104', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Intelligent Systems', 'C4105', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Bio Informatics', 'C4106', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Agent Based Systems', 'C4107', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Embedded Systems', 'C4108', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Computer Graphics', 'C4109', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Computer Science', 'Business Policy', 'C4110', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Programming I', 'C1201', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Mathematics I', 'C1202', 'Undergraduate', '1', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Web Based Application', 'C1203', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Professional Development', 'C1204', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Data Communication', 'C1205', 'Undergraduate', '1', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Introduction to IS', 'C1206', 'Undergraduate', '1', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Information Systems', 'C1207', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Statistics', 'C1208', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Database Management', 'C1209', 'Undergraduate', '1', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Algorithms', 'C1210', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Programming II', 'C2201', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Mathematics II', 'C2202', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Computer Networks I', 'C2203', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Business Studies', 'C2204', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Business Process Management', 'C2205', 'Undergraduate', '2', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Foundation of Information Systems', 'C2206', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Human Computer System', 'C2207', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Systems Design', 'C2208', 'Undergraduate', '2', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Enterprise Systems', 'C2209', 'Undergraduate', '2', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Software Designing', 'C2210', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Introduction to Software Engineering', 'C3201', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'IT Project Management', 'C3202', 'Undergraduate', '3', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Mobile Application', 'C3203', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Software Process', 'C3204', 'Undergraduate', '3', 'Semester 1', 2, '3200', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Wireless Technologies', 'C3205', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Network Programming', 'C3206', 'Undergraduate', '3', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Quality Assurance', 'C3207', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'IT Audit & Control', 'C3208', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Management Systems', 'C3209', 'Undergraduate', '3', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Professional Practice', 'C3210', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Industrial Training', 'C4201', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Agent Based Systems', 'C4202', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Internet of Things', 'C4203', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Enterprise Networks', 'C4204', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Internet of Things advanced', 'C4205', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Data Wirehousing', 'C4206', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Agent Based Application', 'C4207', 'Undergraduate', '4', 'Semester 1', 3, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Disaster Recovery', 'C4208', 'Undergraduate', '4', 'Semester 1', 2, '3000', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'Platform Based Development', 'C4209', 'Undergraduate', '4', 'Semester 1', 3, '2500', 'ggg'),
('School of Computing', 'BSc in Information Systems', 'E-Business Application', 'C4210', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'ggg'),
('School of Computing', 'BSc in Information Technology', 'Design Principles I', 'C1302', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'sdsad'),
('School of Computing', 'BSc in Information Technology', 'Computing Fundamentals', 'C1301', 'Undergraduate', '1', 'Semester 1', 3, '2800', 'sdsad'),
('School of Computing', 'BSc in Information Technology', 'Typography Design', 'C1303', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'sdsad'),
('School of Computing', 'BSc in Information Technology', 'Illustration', 'C1304', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'sdsad'),
('School of Computing', 'BSc in Information Technology', 'Animation Studies', 'C1305', 'Undergraduate', '1', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Concept Development', 'C1306', 'Undergraduate', '1', 'Semester 1', 3, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'World of Technology', 'C1307', 'Undergraduate', '1', 'Semester 1', 2, '3500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Web Based Application', 'C1308', 'Undergraduate', '1', 'Semester 1', 2, '3000', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Digital Imaging', 'C1309', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Statistics', 'C1310', 'Undergraduate', '1', 'Semester 1', 3, '3000', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Design Principles II', 'C2301', 'Undergraduate', '2', 'Semester 1', 3, '3000', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Technology I', 'C2302', 'Undergraduate', '2', 'Semester 1', 2, '3000', 'sdss'),
('School of Computing', 'BSc in Information Technology', '3D Design I', 'C2303', 'Undergraduate', '2', 'Semester 1', 4, '4000', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Web Design I', 'C2304', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Visual Communication', 'C2305', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Project Management', 'C2306', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Interactive Design', 'C2307', 'Undergraduate', '2', 'Semester 1', 3, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Cinematography', 'C2308', 'Undergraduate', '2', 'Semester 1', 3, '3500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Foundation of IT', 'C2309', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Media Art', 'C2310', 'Undergraduate', '2', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Technology II', 'C3301', 'Undergraduate', '3', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', '3D Design II', 'C3302', 'Undergraduate', '3', 'Semester 1', 3, '3300', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Industrial Visit', 'C3303', 'Undergraduate', '3', 'Semester 1', 4, '3500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Group Project', 'C3304', 'Undergraduate', '3', 'Semester 1', 4, '3500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Law & Ethics of IT', 'C3305', 'Undergraduate', '3', 'Semester 1', 2, '2400', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Professional Studies', 'C3306', 'Undergraduate', '3', 'Semester 1', 3, '2400', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Visual Effects', 'C3307', 'Undergraduate', '3', 'Semester 1', 2, '3000', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Dissertation', 'C3308', 'Undergraduate', '3', 'Semester 1', 3, '3000', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'IT Management', 'C3309', 'Undergraduate', '3', 'Semester 1', 2, '2900', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Introduction to Technology', 'C3310', 'Undergraduate', '3', 'Semester 1', 2, '2600', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Web Design II', 'C4301', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Research Methodology', 'C4302', 'Undergraduate', '4', 'Semester 1', 3, '3500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Web Based Application', 'C4303', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Operating Systems', 'C4304', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Development of Enterprise', 'C4305', 'Undergraduate', '4', 'Semester 1', 2, '2500', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Computer Interaction', 'C4306', 'Undergraduate', '4', 'Semester 1', 2, '3400', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Application Development', 'C4307', 'Undergraduate', '4', 'Semester 1', 2, '3400', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Management System', 'C4308', 'Undergraduate', '4', 'Semester 1', 3, '3400', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'Enterprise Application', 'C4309', 'Undergraduate', '4', 'Semester 1', 2, '3200', 'sdss'),
('School of Computing', 'BSc in Information Technology', 'SW Process', 'C4310', 'Undergraduate', '4', 'Semester 1', 3, '3200', 'sdss'),
('School of Business', 'BSc in Business Management', 'sgh', 'dfg', 'Undergraduate', '45', 'Semester 1', 3, '4', 'sfd'),
('School of Business', 'BSc in Business Management', 'dxfgsx', '42x', 'Undergraduate', '745', 'Semester 1', 5, '1', 'xfg'),
('School of Business', 'BSc in Business Management', 'dhr', '452', 'Undergraduate', '15', 'Semester 1', 1, '1', 'dgf'),
('School of Business', 'BSc in Business Management', 'asf', '2', 'Undergraduate', '21', 'Semester 1', 1, '1', 'jn'),
('School of Business', 'BSc in Business Management', 'asd', '51', 'Undergraduate', '1', 'Semester 1', 1, '1', 'hub'),
('School of Business', 'BSc in Business Management', 'sdfg', '12', 'Undergraduate', '1', 'Semester 1', 1, '1', 'sfg'),
('School of Business', 'BSc in Business Management', 'ssdf', '141', 'Undergraduate', '44', 'Semester 1', 1, '2501', 'dhr'),
('School of Business', 'BSc in Business Management', 'ssdf', '1412', 'Undergraduate', '44', 'Semester 1', 1, '3999', 'dhr'),
('School of Business', 'BSc in Business Management', 'ssdf', '14122', 'Undergraduate', '44', 'Semester 1', 1, '4000', 'dhr'),
('School of Business', 'BSc in Business Management', 'ssdf', '1458', 'Undergraduate', '44', 'Semester 1', 1, '4001', 'dhr');

-- --------------------------------------------------------

--
-- Table structure for table `ugstdfees`
--

CREATE TABLE `ugstdfees` (
  `student_id` varchar(30) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `fees` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ugstdfees`
--

INSERT INTO `ugstdfees` (`student_id`, `faculty`, `course`, `fees`) VALUES
('', 'School of Business', 'BSc in Business Management', '10500'),
('45', 'School of Computing', 'BSc in Information Systems', '13500'),
('423', 'School of Business', 'BSc in Management', '3200'),
('23', 'School of Business', 'BSc in Business Management', '42410');

-- --------------------------------------------------------

--
-- Table structure for table `ugstucourse`
--

CREATE TABLE `ugstucourse` (
  `student_id` varchar(30) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `academic_year` varchar(30) NOT NULL,
  `course` varchar(30) NOT NULL,
  `sub_semi1` varchar(20) NOT NULL,
  `sub_semi2` varchar(20) NOT NULL,
  `semi1_fees` int(10) NOT NULL,
  `semi2_fees` int(10) DEFAULT NULL,
  `tot_fees` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ugstucourse`
--

INSERT INTO `ugstucourse` (`student_id`, `faculty`, `academic_year`, `course`, `sub_semi1`, `sub_semi2`, `semi1_fees`, `semi2_fees`, `tot_fees`) VALUES
('4', 'School of Business', 'First year', 'BSc in Business Management', '234', '435', 425, 435, 324);

-- --------------------------------------------------------

--
-- Table structure for table `undergraduatestudent`
--

CREATE TABLE `undergraduatestudent` (
  `full_name` varchar(30) NOT NULL,
  `student_id` varchar(15) NOT NULL,
  `birth_date` varchar(20) NOT NULL,
  `e_mail` varchar(30) NOT NULL,
  `index_no` int(10) NOT NULL,
  `intake` varchar(10) NOT NULL,
  `year` int(10) NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `al_stream` varchar(20) NOT NULL,
  `z_score` varchar(10) NOT NULL,
  `island_rank` int(10) NOT NULL,
  `faculty` varchar(30) NOT NULL,
  `course` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `undergraduatestudent`
--

INSERT INTO `undergraduatestudent` (`full_name`, `student_id`, `birth_date`, `e_mail`, `index_no`, `intake`, `year`, `contact_no`, `gender`, `al_stream`, `z_score`, `island_rank`, `faculty`, `course`, `address`) VALUES
('Vidyasagari Jeganmohan', 'UG/2017/F001', '1996-04-05', 'jjvidya@gmail.com', 17000013, 'February', 2017, '0777458969', 'Female', 'Maths Stream', '1.876', 1409, 'School of Engineering', 'BSc in Civil Engineering', 'No 222, Orchil Lane, Trincomalee'),
('Banushan Puviraj', 'UG/2017/J001', '1995-12-05', 'banushanp@gmail.com', 17000015, 'July', 2017, '0776734567', 'Male', 'Maths Stream', '1.4533', 1288, 'School of Business', 'BSc in Business Management', 'Manipay South,\nManipay.'),
('Mythirege Rajendram', 'UG/2017/F002', '1996-04-12', 'mythirajen@gmail.com', 17000024, 'February', 2017, '0775645344', 'Female', 'Bio Stream', '1.408', 1233, 'School of Computing', 'BSc in Information Systems', 'No 231,\nKirushnan Kovil Road,\nKallady,\nBatticalo.');

-- --------------------------------------------------------

--
-- Table structure for table `userdetail`
--

CREATE TABLE `userdetail` (
  `user_id` int(10) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirm_password` varchar(50) NOT NULL,
  `contact_no` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetail`
--

INSERT INTO `userdetail` (`user_id`, `user_name`, `full_name`, `email`, `password`, `confirm_password`, `contact_no`) VALUES
(16001, 'Pirakavi', 'Pirakavi Santhiran', 'sspirakavi@gmail.com', '123', '123', 773640547),
(6565, '21', 'qeqf', 'we', '123456', '123456', 646465);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `instructordetails`
--
ALTER TABLE `instructordetails`
  ADD PRIMARY KEY (`instructor_id`);

--
-- Indexes for table `pgstucourse`
--
ALTER TABLE `pgstucourse`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `subjectdetails`
--
ALTER TABLE `subjectdetails`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `ugstdfees`
--
ALTER TABLE `ugstdfees`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `ugstucourse`
--
ALTER TABLE `ugstucourse`
  ADD PRIMARY KEY (`student_id`,`sub_semi1`,`sub_semi2`),
  ADD KEY `sub_semi1` (`sub_semi1`),
  ADD KEY `sub_semi1_2` (`sub_semi1`),
  ADD KEY `sub_semi1_3` (`sub_semi1`),
  ADD KEY `sub_semi1_4` (`sub_semi1`),
  ADD KEY `sub_semi1_5` (`sub_semi1`);

--
-- Indexes for table `undergraduatestudent`
--
ALTER TABLE `undergraduatestudent`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `student_id_2` (`student_id`);

--
-- Indexes for table `userdetail`
--
ALTER TABLE `userdetail`
  ADD PRIMARY KEY (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
